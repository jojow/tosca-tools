maintainer       "IBM"
maintainer_email "jwettin@de.ibm.com"
license          "All rights reserved"
description      "Generic helper cookbook"
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version          "1.0"

recipe           "helper", "Default"
recipe           "helper::no_op", "No-op"


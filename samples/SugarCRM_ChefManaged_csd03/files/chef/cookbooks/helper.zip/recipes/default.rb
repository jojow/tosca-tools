#
# Cookbook Name:: helper
# Recipe:: default
#
# Copyright 2012, IBM
#
# All rights reserved - Do Not Redistribute
#



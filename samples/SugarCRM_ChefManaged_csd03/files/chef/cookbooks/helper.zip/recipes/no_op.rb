#
# Cookbook Name:: helper
# Recipe:: no_op
#
# Copyright 2012, IBM
#
# All rights reserved - Do Not Redistribute
#


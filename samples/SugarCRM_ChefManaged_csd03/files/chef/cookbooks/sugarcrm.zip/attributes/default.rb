#
# Cookbook Name:: sugarcrm
# Attributes:: sugarcrm
#
# Copyright 2012, IBM
#
# All rights reserved - Do Not Redistribute
#

default['sugarcrm']['site_admin_username'] = "sugarADMIN"
default['sugarcrm']['site_admin_password'] = "sugarADMIN"
default['sugarcrm']['insert_demo_data'] = "yes"
default['sugarcrm']['license_key'] = "free"

default['sugarcrm']['db_host'] = "localhost"
default['sugarcrm']['db_name'] = "sugarcrmdb"
default['sugarcrm']['db_username'] = "sugaradmin"
default['sugarcrm']['db_password'] = "sugaradmin"

case platform
when "redhat","centos","scientific","fedora","suse","amazon"
  set['sugarcrm']['apache_service'] = "httpd"
when "debian","ubuntu"
  set['sugarcrm']['apache_service'] = "apache2"
else
  set['sugarcrm']['apache_service'] = "apache"
end

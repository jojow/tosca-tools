#
# Cookbook Name:: sugarcrm
# Recipe:: run_silent_install
#
# Copyright 2012, IBM
#
# All rights reserved - Do Not Redistribute
#

#
# Run silent installation of SugarCRM
#
http_request "runSilentInstall" do
  url "http://localhost/sugarcrm/install.php?goto=SilentInstall&cli=true"
end
#remote_file "/var/www/sugarcrm/silent_install.log" do
#  source "http://localhost/sugarcrm/install.php?goto=SilentInstall&cli=true"
#end

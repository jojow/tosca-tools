#
# Cookbook Name:: sugarcrm
# Recipe:: db
#
# Copyright 2012, IBM
#
# All rights reserved - Do Not Redistribute
#

#include_recipe "sugarcrm"
#include_recipe "mysql::server"

#
# Get some data from data bags
#
#root_bag = data_bag_item("sugarcrm-db", "root")
root_password = node['mysql']['server_root_password']
#root_password_generated = root_bag["password_generated"]

#user_bag = data_bag_item("sugarcrm-db", "user")
user_name = node['sugarcrm']['db_username']
user_password = node['sugarcrm']['db_password']

#db_bag = data_bag_item("sugarcrm-db", "db")
db_name = node['sugarcrm']['db_name']

#
# Stop MySQL
#
#service "mysql" do
#	action :stop
#	return [0, 1]
#end

#
# Prepare MySQL configuration
#
#execute "startDaemonTemp" do
#	command "mysqld --skip-grant-tables"
#	action :run
#	timeout 10
#end

#execute "setRootPassword" do
#	command "mysql -u root -e \"FLUSH PRIVILEGES; UPDATE mysql.user SET Password=PASSWORD('#{root_password}') WHERE User='root';\""
#	action :run
#end

#execute "killDeamonTemp" do
#	command "pkill mysql*"
#	action :run
#end

#
# Start MySQL
#
#service "mysql" do
#	action :start
#end

#
# Configure MySQL
#
#execute "setRootPassword" do
#	command "mysqladmin -uroot -p#{root_password_generated} password \"#{root_password}\""
#	action :run
#end

resources_state_path = "/var/log/chef/resources-state"

execute "grantRootPrivileges" do
	command "mysql -uroot -p#{root_password} -e \"GRANT ALL PRIVILEGES ON *.* TO 'root'@'%' IDENTIFIED BY '#{root_password}' WITH GRANT OPTION;\" && touch #{resources_state_path}/.grantRootPrivileges"
	creates "#{resources_state_path}/.grantRootPrivileges"
	action :run
end

execute "createDatabase" do
	command "mysql -uroot -p#{root_password} -e \"CREATE DATABASE #{db_name};\" && touch #{resources_state_path}/.createDatabase"
	creates "#{resources_state_path}/.createDatabase"
	action :run
end

execute "createUser" do
	command "mysql -uroot -p#{root_password} -e \"CREATE USER '#{user_name}'@'%' IDENTIFIED BY '#{user_password}';\" && touch #{resources_state_path}/.createUser"
	creates "#{resources_state_path}/.createUser"
	action :run
end

execute "grantAccess" do
	command "mysql -uroot -p#{root_password} -e \"GRANT ALL ON #{db_name}.* TO '#{user_name}'@'%';\" && touch #{resources_state_path}/.grantAccess"
	creates "#{resources_state_path}/.grantAccess"
	action :run
end

execute "grantSuperuserAccessByHostname" do
	command "mysql -uroot -p#{root_password} -e \"GRANT SUPER ON *.* TO '#{user_name}'@'localhost';\" && touch #{resources_state_path}/.grantSuperuserAccessByHostname"
	creates "#{resources_state_path}/.grantSuperuserAccessByHostname"
	action :run
end

execute "grantSuperuserAccessByIP" do
	command "mysql -uroot -p#{root_password} -e \"GRANT SUPER ON *.* TO '#{user_name}'@'127.0.0.1';\" && touch #{resources_state_path}/.grantSuperuserAccessByIP"
	creates "#{resources_state_path}/.grantSuperuserAccessByIP"
	action :run
end

execute "grantSuperuserAccess" do
	command "mysql -uroot -p#{root_password} -e \"GRANT ALL PRIVILEGES ON *.* TO 'root'@'%' IDENTIFIED BY '#{root_password}' WITH GRANT OPTION; FLUSH PRIVILEGES;\" && touch #{resources_state_path}/.grantSuperuserAccess"
	creates "#{resources_state_path}/.grantSuperuserAccess"
	action :run
end


#
# Update DB state
#
#ruby_block "updateDbState" do
#  block do
#    db_item = data_bag_item("sugarcrm-db", "db")
#    db_item["state"] = "ready"
#    db_item.save
#  end
#  action :create
#end

#
# Cookbook Name:: sugarcrm
# Recipe:: default
#
# Copyright 2012, IBM
#
# All rights reserved - Do Not Redistribute
#

#
# Update package index
#
#execute "runAptGetUpdate" do
#	command "apt-get update"
#	action :run
#end

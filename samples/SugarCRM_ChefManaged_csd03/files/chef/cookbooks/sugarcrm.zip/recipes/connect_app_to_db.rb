#
# Cookbook Name:: sugarcrm
# Recipe:: connect_app_to_db
#
# Copyright 2012, IBM
#
# All rights reserved - Do Not Redistribute
#

#
# Get some data from data bags
#
#db_user_bag = data_bag_item("sugarcrm-db", "user")
db_user_name = node['sugarcrm']['db_username']
db_user_password = node['sugarcrm']['db_password']

#db_bag = data_bag_item("sugarcrm-db", "db")
db_hostname = node['sugarcrm']['db_host']
db_name = node['sugarcrm']['db_name']

license_key = node['sugarcrm']['license_key']
insert_demo_data = node['sugarcrm']['insert_demo_data']
site_admin_password = node['sugarcrm']['site_admin_password']
site_admin_username = node['sugarcrm']['site_admin_username']

#
# Write SugarCRM configuration
#
template "/var/www/sugarcrm/config_si.php" do
  source "config_si.php.erb"
  variables(
    :db_hostname => db_hostname,
    :db_name => db_name,
    :db_username => db_user_name,
    :db_password => db_user_password,
    :license_key => license_key,
    :insert_demo_data => insert_demo_data,
    :site_admin_password => site_admin_password,
    :site_admin_username => site_admin_username
  )
end

#
# Set permissions
#
directory "/var/www/sugarcrm" do
  mode "0755"
end

directory "/var/www/sugarcrm/custom" do
  mode "0766"
end

directory "/var/www/sugarcrm/cache" do
  mode "0777"
end

directory "/var/www/sugarcrm/modules" do
  mode "0777"
end

directory "/var/www/sugarcrm/upload" do
  mode "0777"
end

file "/var/www/sugarcrm/config.php" do
  mode "0766"
  action :touch
end

file "/var/www/sugarcrm/.htaccess" do
  mode "0766"
  action :touch
end

#
# Workaround cos the stuff above isn't workin' perfectly, yet.
#
script "setPermissions" do
  interpreter "sh"
  user "root"
  cwd "/var/www"
  code <<-EOH
  chmod 755 /var/www/sugarcrm/ -R
  chmod 766 /var/www/sugarcrm/config.php
  chmod 766 /var/www/sugarcrm/custom -R
  chmod 766 /var/www/sugarcrm/.htaccess
  chmod 777 /var/www/sugarcrm/cache -R
  chmod 777 /var/www/sugarcrm/modules -R
  chmod 777 /var/www/sugarcrm/upload -R
  EOH
end

#
# .htaccess for log4php
#
template "/var/www/sugarcrm/log4php/.htaccess" do
  source "log4php.htaccess.erb"
  mode "0766"
end

#
# Restart the Apache daemon
#
service node['sugarcrm']['apache_service'] do
  action :restart
end

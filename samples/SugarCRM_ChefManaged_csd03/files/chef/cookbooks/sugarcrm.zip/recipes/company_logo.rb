#
# Cookbook Name:: sugarcrm
# Recipe:: company_logo
#
# Copyright 2012, IBM
#
# All rights reserved - Do Not Redistribute
#

#
# Place company logo
#
cookbook_file "/var/www/sugarcrm/themes/default/images/company_logo.png" do
  source "blue-crm.png"
  mode "0777"
end

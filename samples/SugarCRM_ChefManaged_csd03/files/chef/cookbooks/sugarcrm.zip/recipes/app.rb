#
# Cookbook Name:: sugarcrm
# Recipe:: app
#
# Copyright 2012, IBM
#
# All rights reserved - Do Not Redistribute
#

#include_recipe "sugarcrm"
#include_recipe "apache2"
#include_recipe "apache2::mod_php5"
#include_recipe "php::package"
#include_recipe "php::module_mysql"

#
# Some constants
#
archive_url = "http://downloads.sourceforge.net/project/sugarcrm/2%20-%20SugarCRM%206.4.X/SugarCommunityEdition-6.4.X/SugarCE-6.4.5.zip?r=http%3A%2F%2Fsourceforge.net%2Fprojects%2Fsugarcrm%2Ffiles%2F2%2520-%2520SugarCRM%25206.4.X%2FSugarCommunityEdition-6.4.X%2F&ts=1346441350&use_mirror=garr"
archive_basename = "SugarCE-Full-6.4.5"

resources_state_path = "/var/log/chef/resources-state"

#
# Create info file for testing purposes
#
template "/var/www/info.php" do
  source "info.php.erb"
  mode "0644"
end

#
# Download SugarCRM
#
remote_file "/var/www/#{archive_basename}.zip" do
  source archive_url
  mode "0644"
end

#
# Place SugarCRM archive
#
#cookbook_file "/var/www/#{archive_basename}.zip" do
#  source "#{archive_basename}.zip"
#  mode "0644"
#end

#
# Extract the archive
#
execute "extractArchive" do
  command "cd /var/www && rm -rf #{archive_basename} && rm -rf sugarcrm && unzip -qq -o #{archive_basename}.zip && mv #{archive_basename} sugarcrm && touch #{resources_state_path}/.extractArchive"
  creates "#{resources_state_path}/.extractArchive"
  action :run
end


maintainer       "IBM"
maintainer_email "jwettin@de.ibm.com"
license          "All rights reserved"
description      "Installs and configures SugarCRM"
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version          "0.9"

recipe           "sugarcrm", "Default"
recipe           "sugarcrm::db", "Install database"
recipe           "sugarcrm::app", "Install application"
recipe           "sugarcrm::connect_app_to_db", "Connect application to database"
recipe           "sugarcrm::run_silent_install", "Run silent installation of the application"

#depends "mysql"
#depends "apache2"
#depends "php"

attribute "sugarcrm/site_admin_username",
  :display_name => "SugarCRM Admin User",
  :description => "SugarCRM admin user",
  :default => "sugarADMIN"

attribute "sugarcrm/site_admin_password",
  :display_name => "SugarCRM Admin Password",
  :description => "SugarCRM admin password",
  :default => "sugarADMIN"

attribute "sugarcrm/insert_demo_data",
  :display_name => "Insert Demo Data",
  :description => "Insert demo data into the database? Yes or no?",
  :default => "yes"

attribute "sugarcrm/license_key",
  :display_name => "License Key",
  :description => "The license key for this instance of SugarCRM",
  :default => "free"

attribute "sugarcrm/db_host",
  :display_name => "Database Host",
  :description => "The host where the database running",
  :default => "localhost"

attribute "sugarcrm/db_name",
  :display_name => "Database Name",
  :description => "The name of the database",
  :default => "sugardb"

attribute "sugarcrm/db_username",
  :display_name => "Database Username",
  :description => "The username to access the database",
  :default => "sugaradmin"

attribute "sugarcrm/db_password",
  :display_name => "Database Password",
  :description => "The password to access the database",
  :default => "sugaradmin"
